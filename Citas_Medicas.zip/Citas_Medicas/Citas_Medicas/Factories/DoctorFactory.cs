﻿namespace Citas_Medicas.Factories
{
    using Citas_Medicas.DTOs;
    using Citas_Medicas.Models;

    public class DoctorFactory : IDoctorFactory
    {
        public Doctor CrearDoctor(DoctorDTO dto)
        {
            return new Doctor
            {
                IdUsuario = dto.IdUsuario,
                Nombre = dto.Nombre,
                Apellido = dto.Apellido,
                Edad = dto.Edad,
                Especialidad = dto.Especialidad,
                Telefono = dto.Telefono
            };
        }
    }
}
