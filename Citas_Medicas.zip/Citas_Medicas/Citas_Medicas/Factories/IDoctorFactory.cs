﻿namespace Citas_Medicas.Factories
{
    using Citas_Medicas.DTOs;
    using Citas_Medicas.Models;

    public interface IDoctorFactory
    {
        Doctor CrearDoctor(DoctorDTO dto);
    }
}
