﻿namespace Citas_Medicas.DTOs
{
    public class DoctorDTO
    {
        public int IdDoctor { get; set; } 
        public int IdUsuario { get; set; }
        public string? Nombre { get; set; }
        public string? Apellido { get; set; }
        public int? Edad { get; set; }
        public string? Especialidad { get; set; }
        public string? Telefono { get; set; }
    }
}
