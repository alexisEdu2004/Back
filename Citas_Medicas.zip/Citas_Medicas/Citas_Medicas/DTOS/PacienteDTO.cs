﻿namespace Citas_Medicas.DTOs
{
    public class PacienteDTO
    {
        public int? IdPaciente { get; set; }  // <-- Esta propiedad es útil para identificar el registro
        public int IdUsuario { get; set; }
        public string? Nombre { get; set; }
        public int? Edad { get; set; }
        public decimal? Peso { get; set; }
        public decimal? Estatura { get; set; }
        public string? Genero { get; set; }
        public string? Direccion { get; set; }
        public string? NumeroTelefono { get; set; }
    }
}
