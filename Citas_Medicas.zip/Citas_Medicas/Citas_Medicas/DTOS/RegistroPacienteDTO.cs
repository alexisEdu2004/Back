﻿using System.ComponentModel.DataAnnotations;

namespace Citas_Medicas.DTOs
{
    namespace Citas_Medicas.DTOs
    {
        public class RegistroPacienteDTO
        {
            // Usuario
            public string Correo { get; set; } = null!;
            public string Contraseña { get; set; } = null!;

            // Datos de paciente
            public string? Nombre { get; set; }
            public string? Apellido { get; set; }
            public int? Edad { get; set; }
            public decimal? Peso { get; set; }
            public decimal? Estatura { get; set; }
            public string? Genero { get; set; }
            public string? Direccion { get; set; }
            public string? Telefono { get; set; }
        }
    }

}
