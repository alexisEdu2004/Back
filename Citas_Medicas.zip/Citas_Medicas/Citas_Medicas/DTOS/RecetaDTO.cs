﻿namespace Citas_Medicas.DTOs
{
    public class RecetaDTO
    {
        public int? IdReceta { get; set; }  // Nullable por si es para crear
        public int IdPaciente { get; set; }
        public int IdDoctor { get; set; }
        public DateOnly? FechaEmision { get; set; }

        // Si quieres incluir los detalles de receta en este DTO, puedes agregar esto:
        public List<DetalleRecetaDTO> Detalles { get; set; } = new();
    }
}
