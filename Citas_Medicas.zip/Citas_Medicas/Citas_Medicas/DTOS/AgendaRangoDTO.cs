﻿using Citas_Medicas.DTOs;
using System.ComponentModel.DataAnnotations;

public class AgendaRangoDTO
{
    [Required]
    public int IdDoctor { get; set; }

    [Required]
    [MaxLength(20)]
    public string DiaSemana { get; set; } = null!;

    [Required]
    public TimeOnly HoraInicio { get; set; }

    [Required]
    public TimeOnly HoraFin { get; set; }

    [Range(5, 120)]
    public int IntervaloMinutos { get; set; }
}
