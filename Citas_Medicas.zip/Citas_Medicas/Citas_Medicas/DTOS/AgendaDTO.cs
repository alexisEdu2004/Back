﻿using System.ComponentModel.DataAnnotations;

namespace Citas_Medicas.DTOs
{
    public class AgendaDTO
    {
        public int IdAgenda { get; set; } // <-- Esta propiedad es necesaria para leer y usar agendas existentes

        [Required]
        public int IdDoctor { get; set; }

        [Required]
        [MaxLength(20)]
        public string DiaSemana { get; set; } = null!;

        [Required]
        public TimeOnly Horario { get; set; }
    }

}
