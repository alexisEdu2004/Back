﻿namespace Citas_Medicas.DTOs
{
    public class RolDTO
    {
        public int? IdRol { get; set; }  // Nullable para creación sin Id
        public string NombreRol { get; set; } = null!;
    }

}
