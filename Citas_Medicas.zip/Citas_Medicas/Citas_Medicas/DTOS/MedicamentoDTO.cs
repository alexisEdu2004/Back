﻿namespace Citas_Medicas.DTOs
{
    public class MedicamentoDTO
    {
        public int? IdMedicamento { get; set; } // Nullable por si lo usas para crear
        public string Nombre { get; set; } = null!;
        public string? Descripcion { get; set; }
    }
}
