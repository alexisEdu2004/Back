﻿using System.ComponentModel.DataAnnotations;

namespace Citas_Medicas.DTOs
{
    public class RegistroDoctorDTO
    {
        // Datos de usuario
        [Required]
        [EmailAddress]
        public string Correo { get; set; } = null!;

        [Required]
        [MinLength(8)]
        public string Contraseña { get; set; } = null!;

        // Datos de doctor
        [Required]
        public string Nombre { get; set; } = null!;

        [Required]
        public string Apellido { get; set; } = null!;

        [Range(25, 100, ErrorMessage = "Edad fuera de rango")]
        public int? Edad { get; set; }

        public string? Especialidad { get; set; }

        [Phone]
        public string? Telefono { get; set; }
    }
}
