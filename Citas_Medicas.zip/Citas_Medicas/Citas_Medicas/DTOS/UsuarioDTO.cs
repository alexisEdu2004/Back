﻿namespace Citas_Medicas.DTOs
{
    public class UsuarioDTO
    {
        public int? IdUsuario { get; set; }
        public string Correo { get; set; } = null!;
        public int IdRol { get; set; }
    }

    public class UsuarioRegistroDTO
    {
        public string Correo { get; set; } = null!;
        public string Contraseña { get; set; } = null!;
        public int IdRol { get; set; }
    }

    public class LoginRequestDTO
    {
        public string Correo { get; set; } = null!;
        public string Contraseña { get; set; } = null!;
    }
}
