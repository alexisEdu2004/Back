﻿using Citas_Medicas.DTOs;

public class AgendaDetalleDTO
{
    public int IdAgenda { get; set; }
    public int IdDoctor { get; set; }
    public string DiaSemana { get; set; } = null!;
    public TimeOnly Horario { get; set; }
    public List<CitaDTO> Citas { get; set; } = new();
}
