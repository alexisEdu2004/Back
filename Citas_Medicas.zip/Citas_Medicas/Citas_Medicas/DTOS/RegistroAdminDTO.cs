﻿using System.ComponentModel.DataAnnotations;

namespace Citas_Medicas.DTOs
{
    namespace Citas_Medicas.DTOs
    {
        public class RegistroAdminDTO
        {
            public string Correo { get; set; }
            public string Contraseña { get; set; }
            public string Nombre { get; set; }
            public string Apellido { get; set; }
        }
    }

}
