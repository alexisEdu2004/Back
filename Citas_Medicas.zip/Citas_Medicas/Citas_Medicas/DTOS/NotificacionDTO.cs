﻿namespace Citas_Medicas.DTOs
{
    public class NotificacionDTO
    {
        public int? IdNotificacion { get; set; }  // Nullable para creación sin Id
        public int IdUsuario { get; set; }
        public string? Mensaje { get; set; }
        public DateTime? FechaEnvio { get; set; }
        public bool? Visto { get; set; }
    }

}
