﻿using System.ComponentModel.DataAnnotations;

namespace Citas_Medicas.DTOs
{
    public class SolicitudRecuperacionDTO
    {
        [Required(ErrorMessage = "El correo es obligatorio.")]
        [EmailAddress(ErrorMessage = "El correo no tiene un formato válido.")]
        public string Correo { get; set; }
    }

    public class VerificacionCodigoDTO
    {
        [Required(ErrorMessage = "El correo es obligatorio.")]
        [EmailAddress(ErrorMessage = "El correo no tiene un formato válido.")]
        public string Correo { get; set; }

        [Required(ErrorMessage = "El código es obligatorio.")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "El código debe tener 6 dígitos.")]
        public string Codigo { get; set; }
    }

    public class CambioContrasenaDTO
    {
        [Required(ErrorMessage = "El correo es obligatorio.")]
        [EmailAddress(ErrorMessage = "El correo no tiene un formato válido.")]
        public string Correo { get; set; }

        [Required(ErrorMessage = "El código es obligatorio.")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "El código debe tener 6 dígitos.")]
        public string Codigo { get; set; }

        [Required(ErrorMessage = "La nueva contraseña es obligatoria.")]
        public string NuevaContrasena { get; set; }
    }
}
