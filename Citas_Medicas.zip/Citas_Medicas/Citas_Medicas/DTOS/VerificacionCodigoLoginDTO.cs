﻿using System.ComponentModel.DataAnnotations;

namespace Citas_Medicas.DTOs
{
    public class VerificacionCodigoLoginDTO
    {
        public string Correo { get; set; } = null!;
        public string Codigo { get; set; } = null!;
    }
}
