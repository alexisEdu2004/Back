﻿namespace Citas_Medicas.DTOs
{
    public class CitaDTO
{
    public int IdCita { get; set; }  // me faltaba esta madre, por eso batallaba
    public int IdPaciente { get; set; }
    public int IdDoctor { get; set; }
    public int IdAgenda { get; set; }
    public string? TipoServicio { get; set; }
    public DateOnly FechaCita { get; set; }
    public TimeOnly HoraCita { get; set; }
    public string? EstadoCita { get; set; }
}


}
