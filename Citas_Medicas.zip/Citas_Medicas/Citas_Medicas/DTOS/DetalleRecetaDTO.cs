﻿namespace Citas_Medicas.DTOs
{
    public class DetalleRecetaDTO
    {
        public int? IdDetalleReceta { get; set; }  // Nullable por si lo usas para crear
        public int IdReceta { get; set; }
        public int IdMedicamento { get; set; }
        public string? Descripcion { get; set; }
        public string? Dosis { get; set; }
        public string? Frecuencia { get; set; }
        public string? Duracion { get; set; }

        // Opcional si quieres incluir el nombre del medicamento (solo lectura)
        public string? NombreMedicamento { get; set; }
    }
}
