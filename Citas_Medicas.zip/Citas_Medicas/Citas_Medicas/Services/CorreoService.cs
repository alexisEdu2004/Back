﻿using MailKit.Net.Smtp;
using MimeKit;
using Microsoft.Extensions.Configuration;

public class CorreoService
{
    private readonly IConfiguration _config;

    public CorreoService(IConfiguration config)
    {
        _config = config;
    }

    public async Task EnviarCorreoAsync(string destinatario, string asunto, string cuerpo)
    {
        // Crear el mensaje
        var mensaje = new MimeMessage();
        mensaje.From.Add(new MailboxAddress("Soporte Citas Médicas", _config["Correo:Emisor"]));
        mensaje.To.Add(MailboxAddress.Parse(destinatario));
        mensaje.Subject = asunto;

        // Agregar contenido HTML
        var builder = new BodyBuilder
        {
            HtmlBody = cuerpo
        };
        mensaje.Body = builder.ToMessageBody();

        // Conexión SMTP y envío
        using var smtp = new SmtpClient();
        await smtp.ConnectAsync("smtp.gmail.com", 587, MailKit.Security.SecureSocketOptions.StartTls);
        await smtp.AuthenticateAsync(_config["Correo:Emisor"], _config["Correo:Clave"]);
        await smtp.SendAsync(mensaje);
        await smtp.DisconnectAsync(true);
    }

}
