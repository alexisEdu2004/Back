﻿using Citas_Medicas.Models;
using Citas_Medicas.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Citas_Medicas.Services
{
    public class RecetaManager
    {
        // Instancia única inicializada en forma eager (segura en hilos)
        private static readonly RecetaManager _instancia = new RecetaManager();

        // Constructor privado para evitar instanciación externa
        private RecetaManager() { }

        // Propiedad pública para obtener la instancia singleton
        public static RecetaManager Instancia => _instancia;

        // Método para crear objeto Receta a partir de RecetaDTO
        public Receta CrearReceta(RecetaDTO dto)
        {
            return new Receta
            {
                IdDoctor = dto.IdDoctor,
                IdPaciente = dto.IdPaciente,
                FechaEmision = dto.FechaEmision ?? DateOnly.FromDateTime(DateTime.Today)
            };
        }

        // Método para crear lista de detalles a partir del DTO
        public List<DetalleReceta> CrearDetalles(int idReceta, List<DetalleRecetaDTO> detallesDto)
        {
            return detallesDto.Select(d => new DetalleReceta
            {
                IdReceta = idReceta,
                IdMedicamento = d.IdMedicamento,
                Descripcion = d.Descripcion,
                Dosis = d.Dosis,
                Frecuencia = d.Frecuencia,
                Duracion = d.Duracion
            }).ToList();
        }
    }
}
