﻿public static class PlantillasCorreo
{
    public static string GenerarCuerpoCorreoCodigo(string codigo)
    {
        return $@"
        <!DOCTYPE html>
        <html lang='es'>
        <head>
          <meta charset='UTF-8' />
          <style>
            body {{ font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px; margin: 0; }}
            .container {{ background: #ffffff; max-width: 600px; margin: 0 auto; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
            h2 {{ color: #2e7d6f; }}
            p {{ font-size: 1rem; color: #333333; }}
            .codigo {{
              font-size: 2.5rem;
              color: #2e7d6f;
              border: 3px dashed #2e7d6f;
              padding: 15px 30px;
              margin: 1.5rem auto;
              text-align: center;
              border-radius: 12px;
              font-weight: bold;
              letter-spacing: 0.2em;
              width: fit-content;
              user-select: all;
            }}
            footer {{
              margin-top: 30px;
              font-size: 0.9rem;
              color: #888888;
              text-align: center;
              border-top: 1px solid #eee;
              padding-top: 10px;
            }}
          </style>
        </head>
        <body>
          <div class='container'>
            <h2>Código de verificación Humble Hospital</h2>
            <p>Estimado usuario,</p>
            <p>Para completar tu inicio de sesión, utiliza el siguiente código de verificación:</p>
            <div class='codigo'>{codigo}</div>
            <p>Este código es válido por 10 minutos. Si no solicitaste este código, ignora este mensaje.</p>
            <footer>
              <p><strong>Humble Hospital</strong></p>
              <p>Gracias por confiar en nosotros.</p>
            </footer>
          </div>
        </body>
        </html>
        ";
    }

    public static string GenerarCuerpoCorreoRecuperacion(string codigo)
    {
        return $@"
    <!DOCTYPE html>
    <html lang='es'>
    <head>
      <meta charset='UTF-8' />
      <style>
        body {{ font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px; margin: 0; }}
        .container {{ background: #ffffff; max-width: 600px; margin: 0 auto; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); color: #333; }}
        h2 {{ color: #2e7d6f; text-align: center; }}
        p {{ font-size: 1rem; line-height: 1.5; }}
        .code {{
          display: block;
          margin: 1.5rem auto;
          font-size: 2.5rem;
          letter-spacing: 0.5rem;
          font-weight: 700;
          color: #2e7d6f;
          border: 2px dashed #2e7d6f;
          padding: 1rem 2rem;
          width: fit-content;
          text-align: center;
          border-radius: 12px;
          user-select: all;
        }}
        .footer {{
          font-size: 0.9rem;
          color: #888;
          text-align: center;
          margin-top: 2rem;
          border-top: 1px solid #eee;
          padding-top: 1rem;
        }}
      </style>
    </head>
    <body>
      <div class='container'>
        <h2>Recuperación de Contraseña - Humble Hospital</h2>
        <p>Hola,</p>
        <p>Has solicitado recuperar la contraseña para tu cuenta. Usa el siguiente código para continuar con el proceso:</p>
        <span class='code'>{codigo}</span>
        <p>Si no solicitaste este código, ignora este mensaje.</p>
        <p>Gracias por confiar en nosotros.</p>
        <div class='footer'>© 2025 Humble Hospital. Todos los derechos reservados.</div>
      </div>
    </body>
    </html>
    ";
    }


}
