﻿using Citas_Medicas.Context;
using Citas_Medicas.DTOs;
using Citas_Medicas.Models;
using Citas_Medicas.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Citas_Medicas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RecetaController : ControllerBase
    {
        private readonly DwpContext _context;
        private readonly RecetaManager _recetaManager;

        public RecetaController(DwpContext context)
        {
            _context = context;
            _recetaManager = RecetaManager.Instancia;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<RecetaDTO>>> GetRecetas()
        {
            var recetas = await _context.Recetas
                .Include(r => r.DetalleRecetas)
                .Select(r => new RecetaDTO
                {
                    IdReceta = r.IdReceta,
                    IdDoctor = r.IdDoctor,
                    IdPaciente = r.IdPaciente,
                    FechaEmision = r.FechaEmision,
                    Detalles = r.DetalleRecetas.Select(d => new DetalleRecetaDTO
                    {
                        IdDetalleReceta = d.IdDetalleReceta,
                        IdReceta = d.IdReceta,
                        IdMedicamento = d.IdMedicamento,
                        Descripcion = d.Descripcion,
                        Dosis = d.Dosis,
                        Frecuencia = d.Frecuencia,
                        Duracion = d.Duracion
                    }).ToList()
                })
                .ToListAsync();

            return Ok(recetas);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<RecetaDTO>> GetReceta(int id)
        {
            var receta = await _context.Recetas
                .Include(r => r.DetalleRecetas)
                .FirstOrDefaultAsync(r => r.IdReceta == id);

            if (receta == null)
                return NotFound();

            var recetaDto = new RecetaDTO
            {
                IdReceta = receta.IdReceta,
                IdDoctor = receta.IdDoctor,
                IdPaciente = receta.IdPaciente,
                FechaEmision = receta.FechaEmision,
                Detalles = receta.DetalleRecetas.Select(d => new DetalleRecetaDTO
                {
                    IdDetalleReceta = d.IdDetalleReceta,
                    IdReceta = d.IdReceta,
                    IdMedicamento = d.IdMedicamento,
                    Descripcion = d.Descripcion,
                    Dosis = d.Dosis,
                    Frecuencia = d.Frecuencia,
                    Duracion = d.Duracion
                }).ToList()
            };

            return Ok(recetaDto);
        }

        [HttpPost]
        public async Task<IActionResult> CrearReceta([FromBody] RecetaDTO recetaDto)
        {
            var pacienteExiste = await _context.Pacientes.AnyAsync(p => p.IdPaciente == recetaDto.IdPaciente);
            var doctorExiste = await _context.Doctores.AnyAsync(d => d.IdDoctor == recetaDto.IdDoctor);

            if (!pacienteExiste || !doctorExiste)
                return BadRequest("Paciente o doctor no existente.");

            var receta = _recetaManager.CrearReceta(recetaDto);

            try
            {
                _context.Recetas.Add(receta);
                await _context.SaveChangesAsync();

                var detalles = _recetaManager.CrearDetalles(receta.IdReceta, recetaDto.Detalles);
                _context.DetalleRecetas.AddRange(detalles);
                await _context.SaveChangesAsync();

                return Ok(new { Message = "Receta creada correctamente.", IdReceta = receta.IdReceta });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Error al guardar la receta: " + ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarReceta(int id)
        {
            var receta = await _context.Recetas.Include(r => r.DetalleRecetas)
                                               .FirstOrDefaultAsync(r => r.IdReceta == id);

            if (receta == null)
                return NotFound();

            _context.DetalleRecetas.RemoveRange(receta.DetalleRecetas);
            _context.Recetas.Remove(receta);

            await _context.SaveChangesAsync();

            return Ok(new { Message = "Receta eliminada correctamente." });
        }
    }
}
