﻿using Citas_Medicas.Context;
using Citas_Medicas.DTOs;
using Citas_Medicas.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class RolController : ControllerBase
{
    private readonly DwpContext _context;

    public RolController(DwpContext context)
    {
        _context = context;
    }

    // GET: api/Rol
    [HttpGet]
    public async Task<ActionResult<IEnumerable<RolDTO>>> GetRoles()
    {
        var roles = await _context.Roles
            .Select(r => new RolDTO
            {
                IdRol = r.IdRol,
                NombreRol = r.NombreRol
            })
            .ToListAsync();

        return Ok(roles);
    }

    // GET: api/Rol/5
    [HttpGet("{id}")]
    public async Task<ActionResult<RolDTO>> GetRol(int id)
    {
        var rol = await _context.Roles.FindAsync(id);

        if (rol == null)
            return NotFound();

        var rolDTO = new RolDTO
        {
            IdRol = rol.IdRol,
            NombreRol = rol.NombreRol
        };

        return Ok(rolDTO);
    }

    // POST: api/Rol
    [HttpPost]
    public async Task<ActionResult<RolDTO>> CrearRol([FromBody] RolDTO rolDTO)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        // Validar que no exista un rol con el mismo nombre
        if (await _context.Roles.AnyAsync(r => r.NombreRol == rolDTO.NombreRol))
            return BadRequest("El nombre del rol ya está registrado.");

        var rol = new Rol
        {
            NombreRol = rolDTO.NombreRol
        };

        _context.Roles.Add(rol);
        await _context.SaveChangesAsync();

        rolDTO.IdRol = rol.IdRol;

        return CreatedAtAction(nameof(GetRol), new { id = rol.IdRol }, rolDTO);
    }

    // PUT: api/Rol/5
    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarRol(int id, [FromBody] RolDTO dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        if (dto.IdRol != null && dto.IdRol != id)
            return BadRequest("El ID del DTO no coincide con el de la ruta.");

        var rol = await _context.Roles.FindAsync(id);
        if (rol == null)
            return NotFound();

        // Verificar si otro rol ya tiene ese nombre
        bool nombreDuplicado = await _context.Roles.AnyAsync(r => r.NombreRol == dto.NombreRol && r.IdRol != id);
        if (nombreDuplicado)
            return BadRequest("Ya existe otro rol con ese nombre.");

        rol.NombreRol = dto.NombreRol;

        _context.Entry(rol).State = EntityState.Modified;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    // DELETE: api/Rol/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarRol(int id)
    {
        var rol = await _context.Roles
            .Include(r => r.Usuarios)
            .FirstOrDefaultAsync(r => r.IdRol == id);

        if (rol == null)
            return NotFound();

        if (rol.Usuarios.Any())
            return BadRequest("No se puede eliminar un rol que tiene usuarios asignados.");

        _context.Roles.Remove(rol);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
