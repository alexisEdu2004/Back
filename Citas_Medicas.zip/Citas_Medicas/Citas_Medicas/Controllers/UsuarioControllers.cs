﻿using Citas_Medicas.Context;
using Citas_Medicas.DTOs;
using Citas_Medicas.DTOs.Citas_Medicas.DTOs;
using Citas_Medicas.Helpers;
using Citas_Medicas.Models;
using Citas_Medicas.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class UserController : ControllerBase
{
    private readonly CorreoService _correoService;
    private readonly DwpContext _context;
    private readonly JwtTokenGenerator _tokenGenerator;

    public UserController(DwpContext context, IConfiguration config, CorreoService correoService)
    {
        _context = context;
        _tokenGenerator = new JwtTokenGenerator(config);
        _correoService = correoService;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<UsuarioDTO>>> GetUsuarios()
    {
        var usuarios = await _context.Usuarios
            .Select(u => new UsuarioDTO
            {
                IdUsuario = u.IdUsuario,
                Correo = u.Correo,
                IdRol = u.IdRol
            })
            .ToListAsync();

        return Ok(usuarios);
    }

    [HttpPost("RegistrarPaciente")]
    public async Task<IActionResult> RegistrarPaciente([FromBody] RegistroPacienteDTO dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        if (!ValidacionesUtils.EsCorreoValido(dto.Correo))
            return BadRequest("El correo electrónico no tiene un formato válido.");

        if (_context.Usuarios.Any(u => u.Correo == dto.Correo))
            return BadRequest("El correo ya está registrado.");

        if (!ValidacionesUtils.EsContrasenaSegura(dto.Contraseña))
            return BadRequest("La contraseña debe tener al menos 8 caracteres, una mayúscula, una minúscula, un número y un carácter especial.");

        var usuario = new Usuario
        {
            Correo = dto.Correo,
            Contraseña = BCrypt.Net.BCrypt.HashPassword(dto.Contraseña),
            IdRol = 3
        };

        _context.Usuarios.Add(usuario);
        await _context.SaveChangesAsync();

        var paciente = new Paciente
        {
            IdUsuario = usuario.IdUsuario,
            Nombre = dto.Nombre,
            Apellido = dto.Apellido,
            Edad = dto.Edad,
            Peso = dto.Peso,
            Estatura = dto.Estatura,
            Genero = dto.Genero,
            Direccion = dto.Direccion,
            Telefono = dto.Telefono
        };

        _context.Pacientes.Add(paciente);
        await _context.SaveChangesAsync();

        return Ok(new
        {
            Message = "Paciente registrado exitosamente.",
            usuario.IdUsuario,
            paciente.IdPaciente
        });
    }

    //Aqui cambien por su correo personal para que puedan ingresar por la verificacion en dos pasos
	[HttpPost("CrearAdminTest")] 
	public async Task<IActionResult> CrearAdminTest()
	{
		if (await _context.Usuarios.AnyAsync(u => u.Correo == "voltodyssey@gmail.com"))
			return BadRequest("Ya existe un admin con ese correo.");

		var admin = new Usuario
		{
			Correo = "voltodyssey@gmail.com",
			Contraseña = BCrypt.Net.BCrypt.HashPassword("Admin123"),
			IdRol = 1
		};

		_context.Usuarios.Add(admin);
		await _context.SaveChangesAsync();

		return Ok("Administrador de prueba creado con éxito.");
	}


	[HttpPost("RegistrarAdmin")]
    public async Task<IActionResult> RegistrarAdmin(
        [FromHeader(Name = "x-user-role")] int? role,
        [FromBody] RegistroAdminDTO dto)
    {
        if (role != 1)
            return Unauthorized("Solo los administradores pueden registrar otros administradores.");

        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        if (!ValidacionesUtils.EsCorreoValido(dto.Correo))
            return BadRequest("Correo inválido.");

        if (_context.Usuarios.Any(u => u.Correo == dto.Correo))
            return BadRequest("Este correo ya está registrado.");

        if (!ValidacionesUtils.EsContrasenaSegura(dto.Contraseña))
            return BadRequest("Contraseña insegura.");

        var usuario = new Usuario
        {
            Correo = dto.Correo,
            Contraseña = BCrypt.Net.BCrypt.HashPassword(dto.Contraseña),
            IdRol = 1
        };

        _context.Usuarios.Add(usuario);
        await _context.SaveChangesAsync();

        return Ok(new
        {
            Message = "Administrador registrado correctamente.",
            usuario.IdUsuario
        });
    }

    [HttpPost("Login")]
    public async Task<IActionResult> IniciarSesion([FromBody] LoginRequestDTO request)
    {
        var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.Correo == request.Correo);
        if (usuario == null || !BCrypt.Net.BCrypt.Verify(request.Contraseña, usuario.Contraseña))
            return Unauthorized("Correo o contraseña incorrectos.");

        var codigo = new Random().Next(100000, 999999).ToString();
        var expiracion = DateTime.UtcNow.AddMinutes(10);
        CodigosTemporales.CodigosLogin[usuario.Correo] = (codigo, expiracion);

        // Usar plantilla para el cuerpo
        string cuerpo = PlantillasCorreo.GenerarCuerpoCorreoCodigo(codigo);

        await _correoService.EnviarCorreoAsync(usuario.Correo, "Código de verificación - Humble Hospital", cuerpo);

        return Ok(new
        {
            Message = "Código enviado al correo.",
            Paso = "VerificacionPendiente",
            Correo = usuario.Correo
        });
    }


    [HttpPost("VerificarCodigoLogin")]
    public IActionResult VerificarCodigoLogin([FromBody] VerificacionCodigoDTO dto)
    {
        if (CodigosTemporales.CodigosLogin.TryGetValue(dto.Correo, out var data))
        {
            if (data.Codigo != dto.Codigo)
                return BadRequest("Código incorrecto.");

            if (data.Expiracion < DateTime.UtcNow)
                return BadRequest("El código ha expirado.");

            var usuario = _context.Usuarios.FirstOrDefault(u => u.Correo == dto.Correo);
            if (usuario == null)
                return NotFound("Usuario no encontrado.");

            var token = _tokenGenerator.GenerarToken(usuario.IdUsuario, usuario.IdRol);

            HttpContext.Response.Cookies.Append("jwtToken", token, new CookieOptions
            {
                HttpOnly = true,
                Secure = true,
                SameSite = SameSiteMode.Strict,
                Expires = DateTime.UtcNow.AddMinutes(30)
            });

            // Eliminar código usado
            CodigosTemporales.CodigosLogin.Remove(dto.Correo);

            return Ok(new
            {
                Message = "Inicio de sesión exitoso.",
                IdUsuario = usuario.IdUsuario,
                IdRol = usuario.IdRol
            });
        }

        return NotFound("No se encontró un código para este correo.");
    }

    [HttpPost("ReenviarCodigoLogin")]
    public async Task<IActionResult> ReenviarCodigoLogin([FromBody] CorreoDTO dto)
    {
        var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.Correo == dto.Correo);
        if (usuario == null)
            return NotFound("No se encontró un usuario con ese correo.");

        var codigo = new Random().Next(100000, 999999).ToString();
        var expiracion = DateTime.UtcNow.AddMinutes(10);
        CodigosTemporales.CodigosLogin[usuario.Correo] = (codigo, expiracion);

        // Usar la misma plantilla para reenviar
        string cuerpo = PlantillasCorreo.GenerarCuerpoCorreoCodigo(codigo);

        await _correoService.EnviarCorreoAsync(usuario.Correo, "Código de verificación - Humble Hospital", cuerpo);

        return Ok(new { Message = "Código reenviado al correo." });
    }

    // DTO para recibir solo correo
    public class CorreoDTO
    {
        public string Correo { get; set; }
    }


    [HttpPost("RecuperarContrasena")]
    public async Task<IActionResult> RecuperarContrasena([FromBody] SolicitudRecuperacionDTO solicitud)
    {
        var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.Correo == solicitud.Correo);
        if (usuario == null)
            return NotFound("No se encontró un usuario con ese correo.");

        var codigo = new Random().Next(100000, 999999).ToString();
        var expiracion = DateTime.UtcNow.AddMinutes(10);

        // Guardar código recuperación en diccionario específico
        CodigosTemporales.CodigosRecuperacion[solicitud.Correo] = (codigo, expiracion);

        // Usar la plantilla centralizada para generar el cuerpo del correo
        string cuerpo = PlantillasCorreo.GenerarCuerpoCorreoRecuperacion(codigo);

        await _correoService.EnviarCorreoAsync(solicitud.Correo, "Código para recuperar contraseña - Humble Hospital", cuerpo);

        return Ok("Código enviado al correo.");
    }

    [HttpPost("ReenviarCodigoRecuperacion")]
    public async Task<IActionResult> ReenviarCodigoRecuperacion([FromBody] CorreoDTO dto)
    {
        var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.Correo == dto.Correo);
        if (usuario == null)
            return NotFound("No se encontró un usuario con ese correo.");

        var codigo = new Random().Next(100000, 999999).ToString();
        var expiracion = DateTime.UtcNow.AddMinutes(10);
        CodigosTemporales.CodigosRecuperacion[usuario.Correo] = (codigo, expiracion);

        // Usar la plantilla para recuperación
        string cuerpo = PlantillasCorreo.GenerarCuerpoCorreoRecuperacion(codigo);

        await _correoService.EnviarCorreoAsync(usuario.Correo, "Código para recuperar contraseña - Humble Hospital", cuerpo);

        return Ok(new { Message = "Código reenviado al correo." });
    }



    [HttpPost("VerificarCodigo")]
    public IActionResult VerificarCodigo([FromBody] VerificacionCodigoDTO dto)
    {
        if (CodigosTemporales.CodigosRecuperacion.TryGetValue(dto.Correo, out var data))
        {
            if (data.Codigo != dto.Codigo)
                return BadRequest("Código incorrecto.");

            if (data.Expiracion < DateTime.UtcNow)
                return BadRequest("El código ha expirado.");

            return Ok("Código válido");
        }

        return NotFound("No se encontró un código para ese correo.");
    }


    [HttpPost("CambiarContrasena")]
    public async Task<IActionResult> CambiarContrasena([FromBody] CambioContrasenaDTO dto)
    {
        if (!ValidacionesUtils.EsContrasenaSegura(dto.NuevaContrasena))
            return BadRequest("La nueva contraseña no es segura.");

        if (CodigosTemporales.CodigosRecuperacion.TryGetValue(dto.Correo, out var data))
        {
            if (data.Codigo != dto.Codigo)
                return BadRequest("Código incorrecto.");

            if (data.Expiracion < DateTime.UtcNow)
                return BadRequest("El código ha expirado.");

            var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.Correo == dto.Correo);
            if (usuario == null)
                return NotFound("Usuario no encontrado.");

            usuario.Contraseña = BCrypt.Net.BCrypt.HashPassword(dto.NuevaContrasena);
            await _context.SaveChangesAsync();

            CodigosTemporales.CodigosRecuperacion.Remove(dto.Correo);

            return Ok("Contraseña cambiada exitosamente.");
        }

        return NotFound("No se encontró un código para este correo.");
    }

    [HttpPost("Logout")]
    public IActionResult Logout()
    {
        Response.Cookies.Delete("jwtToken");
        return Ok(new { Message = "Sesión cerrada correctamente." });
    }
}
