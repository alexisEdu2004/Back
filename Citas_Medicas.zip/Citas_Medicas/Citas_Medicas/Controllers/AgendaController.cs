﻿using Citas_Medicas.Context;
using Citas_Medicas.DTOs;
using Citas_Medicas.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Citas_Medicas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AgendaController : ControllerBase
    {
        private readonly DwpContext _context;

        public AgendaController(DwpContext context)
        {
            _context = context;
        }

        // GET: api/Agenda/Disponibles
        [HttpGet("Disponibles")]
        public async Task<ActionResult<IEnumerable<object>>> GetAgendasDisponibles()
        {
            var agendas = await (from agenda in _context.Agendas
                                 join cita in _context.Citas
                                 on agenda.IdDoctor equals cita.IdDoctor
                                 where cita.FechaCita > DateOnly.FromDateTime(DateTime.Now)
                                 select new
                                 {
                                     agenda.IdAgenda,
                                     agenda.DiaSemana,
                                     agenda.Horario,
                                     cita.FechaCita,
                                     cita.HoraCita
                                 }).ToListAsync();

            return Ok(agendas);
        }

        // GET: api/Agenda/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AgendaDetalleDTO>> GetAgendaConCitas(int id)
        {
            var agenda = await _context.Agendas
                .Include(a => a.Citas)
                .FirstOrDefaultAsync(a => a.IdAgenda == id);

            if (agenda == null)
                return NotFound();

            var agendaDto = new AgendaDetalleDTO
            {
                IdAgenda = agenda.IdAgenda,
                IdDoctor = agenda.IdDoctor,
                DiaSemana = agenda.DiaSemana ?? "",
                Horario = agenda.Horario ?? TimeOnly.MinValue,
                Citas = agenda.Citas.Select(c => new CitaDTO
                {
                    IdCita = c.IdCita,
                    IdPaciente = c.IdPaciente,
                    IdDoctor = c.IdDoctor,
                    IdAgenda = c.IdAgenda,
                    TipoServicio = c.TipoServicio,
                    FechaCita = c.FechaCita,
                    HoraCita = c.HoraCita,
                    EstadoCita = c.EstadoCita
                }).ToList()
            };

            return Ok(agendaDto);
        }

        // GET: api/Agenda/doctor/3
        [HttpGet("doctor/{idDoctor}")]
        public async Task<ActionResult<IEnumerable<AgendaDetalleDTO>>> GetAgendasPorDoctor(int idDoctor)
        {
            var agendas = await _context.Agendas
                .Where(a => a.IdDoctor == idDoctor)
                .Include(a => a.Citas)
                .Select(a => new AgendaDetalleDTO
                {
                    IdAgenda = a.IdAgenda,
                    IdDoctor = a.IdDoctor,
                    DiaSemana = a.DiaSemana ?? "",
                    Horario = a.Horario ?? TimeOnly.MinValue,
                    Citas = a.Citas.Select(c => new CitaDTO
                    {
                        IdCita = c.IdCita,
                        IdPaciente = c.IdPaciente,
                        IdDoctor = c.IdDoctor,
                        IdAgenda = c.IdAgenda,
                        TipoServicio = c.TipoServicio,
                        FechaCita = c.FechaCita,
                        HoraCita = c.HoraCita,
                        EstadoCita = c.EstadoCita
                    }).ToList()
                }).ToListAsync();

            return Ok(agendas);
        }

        // POST: api/Agenda
        [HttpPost]
        public async Task<ActionResult> CrearAgenda([FromBody] AgendaDTO agendaDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var doctorExiste = await _context.Doctores.AnyAsync(d => d.IdDoctor == agendaDto.IdDoctor);
            if (!doctorExiste)
                return BadRequest($"No se encontró el doctor con ID {agendaDto.IdDoctor}.");

            var agendaExistente = await _context.Agendas.AnyAsync(a =>
                a.IdDoctor == agendaDto.IdDoctor &&
                a.DiaSemana == agendaDto.DiaSemana &&
                a.Horario == agendaDto.Horario);

            if (agendaExistente)
                return BadRequest("Ya existe una agenda con ese día y horario para este doctor.");

            string[] diasValidos = { "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo" };
            if (!diasValidos.Contains(agendaDto.DiaSemana))
                return BadRequest("Día de la semana no válido.");

            var agenda = new Agenda
            {
                IdDoctor = agendaDto.IdDoctor,
                DiaSemana = agendaDto.DiaSemana,
                Horario = agendaDto.Horario
            };

            _context.Agendas.Add(agenda);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetAgendaConCitas), new { id = agenda.IdAgenda }, agendaDto);
        }

        // POST: api/Agenda/CrearRango
        [HttpPost("CrearRango")]
        public async Task<IActionResult> CrearAgendaPorRango([FromBody] AgendaRangoDTO dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (dto.HoraFin <= dto.HoraInicio)
                return BadRequest("La hora de fin debe ser mayor que la hora de inicio.");

            var doctorExiste = await _context.Doctores.AnyAsync(d => d.IdDoctor == dto.IdDoctor);
            if (!doctorExiste)
                return BadRequest($"No se encontró el doctor con ID {dto.IdDoctor}.");

            var horaActual = dto.HoraInicio;
            var nuevasAgendas = new List<Agenda>();

            while (horaActual < dto.HoraFin)
            {
                bool yaExiste = await _context.Agendas.AnyAsync(a =>
                    a.IdDoctor == dto.IdDoctor &&
                    a.DiaSemana == dto.DiaSemana &&
                    a.Horario == horaActual);

                if (!yaExiste)
                {
                    nuevasAgendas.Add(new Agenda
                    {
                        IdDoctor = dto.IdDoctor,
                        DiaSemana = dto.DiaSemana,
                        Horario = horaActual
                    });
                }

                horaActual = horaActual.AddMinutes(dto.IntervaloMinutos);
            }

            if (nuevasAgendas.Count == 0)
                return BadRequest("Todas las agendas ya estaban registradas para ese rango.");

            _context.Agendas.AddRange(nuevasAgendas);
            await _context.SaveChangesAsync();

            return Ok(new { Message = $"{nuevasAgendas.Count} agendas creadas exitosamente." });
        }

        // PUT: api/Agenda/5
        [HttpPut("{id}")]
        public async Task<IActionResult> ActualizarAgenda(int id, [FromBody] AgendaDTO dto)
        {
            var agenda = await _context.Agendas.FindAsync(id);
            if (agenda == null)
                return NotFound();

            agenda.DiaSemana = dto.DiaSemana;
            agenda.Horario = dto.Horario;
            agenda.IdDoctor = dto.IdDoctor;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/Agenda/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarAgenda(int id)
        {
            var agenda = await _context.Agendas
                .Include(a => a.Citas)
                .FirstOrDefaultAsync(a => a.IdAgenda == id);

            if (agenda == null)
                return NotFound();

            _context.Citas.RemoveRange(agenda.Citas);
            _context.Agendas.Remove(agenda);

            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
