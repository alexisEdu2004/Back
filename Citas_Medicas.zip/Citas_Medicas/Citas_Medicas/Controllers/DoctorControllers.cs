﻿using Citas_Medicas.Context;
using Citas_Medicas.DTOs;
using Citas_Medicas.DTOs.Citas_Medicas.DTOs;
using Citas_Medicas.Factories;
using Citas_Medicas.Helpers;
using Citas_Medicas.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class DoctorController : ControllerBase
{
    private readonly DwpContext _context;
    private readonly IDoctorFactory _doctorFactory;

    public DoctorController(DwpContext context, IDoctorFactory doctorFactory)
    {
        _context = context;
        _doctorFactory = doctorFactory;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<DoctorDTO>>> GetDoctores()
    {
        var doctores = await _context.Doctores
            .Select(d => new DoctorDTO
            {
                IdDoctor = d.IdDoctor,
                IdUsuario = d.IdUsuario,
                Nombre = d.Nombre,
                Apellido = d.Apellido,
                Edad = d.Edad,
                Especialidad = d.Especialidad,
                Telefono = d.Telefono
            })
            .ToListAsync();

        return Ok(doctores);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<DoctorDTO>> GetDoctor(int id)
    {
        var doctor = await _context.Doctores
            .Where(d => d.IdDoctor == id)
            .Select(d => new DoctorDTO
            {
                IdDoctor = d.IdDoctor,
                IdUsuario = d.IdUsuario,
                Nombre = d.Nombre,
                Apellido = d.Apellido,
                Edad = d.Edad,
                Especialidad = d.Especialidad,
                Telefono = d.Telefono
            })
            .FirstOrDefaultAsync();

        if (doctor == null)
            return NotFound();

        return Ok(doctor);
    }

    [HttpGet("PorUsuario/{idUsuario}")]
    public async Task<ActionResult<int>> GetIdDoctorPorUsuario(int idUsuario)
    {
        var doctor = await _context.Doctores.FirstOrDefaultAsync(d => d.IdUsuario == idUsuario);
        if (doctor == null)
            return NotFound("No se encontró doctor para ese usuario");
        return Ok(doctor.IdDoctor);
    }


    [HttpPost("Registrar")]
    public async Task<IActionResult> RegistrarDoctor([FromBody] RegistroDoctorDTO dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        // Validar formato del correo
        if (!ValidacionesUtils.EsCorreoValido(dto.Correo))
            return BadRequest("El correo electrónico no tiene un formato válido.");

        // Verificar si ya existe el correo
        if (await _context.Usuarios.AnyAsync(u => u.Correo == dto.Correo))
            return BadRequest("El correo ya está registrado.");

        // Validar seguridad de la contraseña
        if (!ValidacionesUtils.EsContrasenaSegura(dto.Contraseña))
            return BadRequest("La contraseña debe tener al menos 8 caracteres, una mayúscula, una minúscula, un número y un carácter especial.");

        // Crear el usuario con contraseña hasheada
        var usuario = new Usuario
        {
            Correo = dto.Correo,
            Contraseña = BCrypt.Net.BCrypt.HashPassword(dto.Contraseña),
            IdRol = 2 // Doctor
        };

        _context.Usuarios.Add(usuario);
        await _context.SaveChangesAsync();

        // Crear el doctor asociado al usuario
        var doctor = new Doctor
        {
            IdUsuario = usuario.IdUsuario,
            Nombre = dto.Nombre,
            Apellido = dto.Apellido,
            Edad = dto.Edad,
            Especialidad = dto.Especialidad,
            Telefono = dto.Telefono
        };

        _context.Doctores.Add(doctor);
        await _context.SaveChangesAsync();

        return Ok(new
        {
            Message = "Doctor registrado correctamente.",
            IdUsuario = usuario.IdUsuario,
            IdDoctor = doctor.IdDoctor
        });
    }



    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarDoctor(int id, [FromBody] DoctorDTO doctorDto)
    {
        if (id != doctorDto.IdDoctor)
            return BadRequest("El ID no coincide.");

        var doctorExistente = await _context.Doctores.FindAsync(id);
        if (doctorExistente == null)
            return NotFound();

        var usuarioExiste = await _context.Usuarios.AnyAsync(u => u.IdUsuario == doctorDto.IdUsuario);
        if (!usuarioExiste)
            return BadRequest("El usuario especificado no existe.");

        doctorExistente.IdUsuario = doctorDto.IdUsuario;
        doctorExistente.Nombre = doctorDto.Nombre;
        doctorExistente.Apellido = doctorDto.Apellido;
        doctorExistente.Edad = doctorDto.Edad;
        doctorExistente.Especialidad = doctorDto.Especialidad;
        doctorExistente.Telefono = doctorDto.Telefono;

        await _context.SaveChangesAsync();

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarDoctor(int id)
    {
        var doctor = await _context.Doctores.FindAsync(id);
        if (doctor == null)
            return NotFound();

        _context.Doctores.Remove(doctor);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
