﻿using Citas_Medicas.Models;
using Citas_Medicas.DTOs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Citas_Medicas.Context;
using Citas_Medicas.Services;

[ApiController]
[Route("api/[controller]")]
public class CitaController : ControllerBase
{
    private readonly DwpContext _context;
    private readonly RecetaManager _recetaManager;

    public CitaController(DwpContext context)
    {
        _context = context;
        _recetaManager = RecetaManager.Instancia; // Singleton
    }

    // GET: api/Cita
    [HttpGet]
    public async Task<ActionResult<IEnumerable<CitaDTO>>> GetCitas()
    {
        var citas = await _context.Citas
            .Select(c => new CitaDTO
            {
                IdCita = c.IdCita,
                IdPaciente = c.IdPaciente,
                IdDoctor = c.IdDoctor,
                IdAgenda = c.IdAgenda,
                TipoServicio = c.TipoServicio,
                FechaCita = c.FechaCita,
                HoraCita = c.HoraCita,
                EstadoCita = c.EstadoCita
            })
            .ToListAsync();

        return Ok(citas);
    }

    // GET: api/Cita/paciente/5
    [HttpGet("paciente/{idPaciente}")]
    public async Task<ActionResult<IEnumerable<CitaDTO>>> ObtenerCitasPorPaciente(int idPaciente)
    {
        var citas = await _context.Citas
            .Where(c => c.IdPaciente == idPaciente)
            .Select(c => new CitaDTO
            {
                IdCita = c.IdCita,
                IdPaciente = c.IdPaciente,
                IdDoctor = c.IdDoctor,
                IdAgenda = c.IdAgenda,
                TipoServicio = c.TipoServicio,
                FechaCita = c.FechaCita,
                HoraCita = c.HoraCita,
                EstadoCita = c.EstadoCita
            })
            .ToListAsync();

        if (citas == null || citas.Count == 0)
            return NotFound("No se encontraron citas para este paciente.");

        return Ok(citas);
    }

    [HttpGet("paciente/{idPaciente}/proxima")]
    public async Task<ActionResult<CitaDTO>> ObtenerProximaCita(int idPaciente)
    {
        var ahora = DateTime.Now;

        var proximaCita = await _context.Citas
            .Where(c => c.IdPaciente == idPaciente
                        && (c.EstadoCita.ToLower() != "cancelada")
                        && (c.FechaCita > DateOnly.FromDateTime(ahora)
                            || (c.FechaCita == DateOnly.FromDateTime(ahora) && c.HoraCita >= TimeOnly.FromDateTime(ahora))))
            .OrderBy(c => c.FechaCita)
            .ThenBy(c => c.HoraCita)
            .Select(c => new CitaDTO
            {
                IdCita = c.IdCita,
                IdPaciente = c.IdPaciente,
                IdDoctor = c.IdDoctor,
                IdAgenda = c.IdAgenda,
                TipoServicio = c.TipoServicio,
                FechaCita = c.FechaCita,
                HoraCita = c.HoraCita,
                EstadoCita = c.EstadoCita
            })
            .FirstOrDefaultAsync();

        if (proximaCita == null)
            return NotFound("No se encontró ninguna próxima cita.");

        return Ok(proximaCita);
    }


    // POST: api/Cita
    [HttpPost]
    public async Task<ActionResult<CitaDTO>> CrearCita([FromBody] CitaDTO citaDto)
    {
        // Validación básica
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var pacienteExiste = await _context.Pacientes.AnyAsync(p => p.IdPaciente == citaDto.IdPaciente);
        var doctorExiste = await _context.Doctores.AnyAsync(d => d.IdDoctor == citaDto.IdDoctor);
        var agendaExiste = await _context.Agendas.AnyAsync(a => a.IdAgenda == citaDto.IdAgenda);

        if (!pacienteExiste || !doctorExiste || !agendaExiste)
            return BadRequest("El paciente, doctor o agenda especificados no existen.");

        var cita = new Cita
        {
            IdPaciente = citaDto.IdPaciente,
            IdDoctor = citaDto.IdDoctor,
            IdAgenda = citaDto.IdAgenda,
            TipoServicio = citaDto.TipoServicio,
            FechaCita = citaDto.FechaCita,
            HoraCita = citaDto.HoraCita,
            EstadoCita = citaDto.EstadoCita
        };

        _context.Citas.Add(cita);
        await _context.SaveChangesAsync();

        citaDto.IdCita = cita.IdCita;

        return CreatedAtAction(nameof(GetCitas), new { id = cita.IdCita }, citaDto);
    }

    // PUT: api/Cita/5
    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarCita(int id, [FromBody] CitaDTO citaDto)
    {
        if (id != citaDto.IdCita)
            return BadRequest("El ID de la cita no coincide.");

        var cita = await _context.Citas.FindAsync(id);
        if (cita == null)
            return NotFound();

        // Verifica si el estado cambia a confirmado o realizado para crear receta
        bool estadoAntes = cita.EstadoCita?.ToLower() == "confirmada" || cita.EstadoCita?.ToLower() == "realizada";
        bool estadoDespues = citaDto.EstadoCita?.ToLower() == "confirmada" || citaDto.EstadoCita?.ToLower() == "realizada";

        cita.IdPaciente = citaDto.IdPaciente;
        cita.IdDoctor = citaDto.IdDoctor;
        cita.IdAgenda = citaDto.IdAgenda;
        cita.TipoServicio = citaDto.TipoServicio;
        cita.FechaCita = citaDto.FechaCita;
        cita.HoraCita = citaDto.HoraCita;
        cita.EstadoCita = citaDto.EstadoCita;

        try
        {
            await _context.SaveChangesAsync();

            // Crear receta solo si el estado cambió de no confirmado a confirmado o realizado
            if (!estadoAntes && estadoDespues)
            {
                var recetaExiste = await _context.Recetas.AnyAsync(r =>
                    r.IdDoctor == cita.IdDoctor &&
                    r.IdPaciente == cita.IdPaciente &&
                    r.FechaEmision == DateOnly.FromDateTime(DateTime.Now));

                if (!recetaExiste)
                {
                    var recetaDto = new RecetaDTO
                    {
                        IdDoctor = cita.IdDoctor,
                        IdPaciente = cita.IdPaciente,
                        FechaEmision = DateOnly.FromDateTime(DateTime.Now),
                        Detalles = new List<DetalleRecetaDTO>() // Vacía al principio
                    };

                    var receta = _recetaManager.CrearReceta(recetaDto);
                    _context.Recetas.Add(receta);
                    await _context.SaveChangesAsync();
                }
            }
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!_context.Citas.Any(e => e.IdCita == id))
                return NotFound();
            else
                throw;
        }

        return NoContent();
    }

    // DELETE: api/Cita/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarCita(int id)
    {
        var cita = await _context.Citas.FindAsync(id);
        if (cita == null)
            return NotFound();

        _context.Citas.Remove(cita);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
