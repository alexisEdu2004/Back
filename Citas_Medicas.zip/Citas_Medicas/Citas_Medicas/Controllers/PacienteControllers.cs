﻿using Citas_Medicas.Context;
using Citas_Medicas.DTOs;
using Citas_Medicas.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class PacienteController : ControllerBase
{
    private readonly DwpContext _context;

    public PacienteController(DwpContext context)
    {
        _context = context;
    }

    // GET: api/Paciente
    [HttpGet]
    public async Task<ActionResult<IEnumerable<PacienteDTO>>> GetPacientes()
    {
        var pacientesDto = await _context.Pacientes
            .Select(p => new PacienteDTO
            {
                IdPaciente = p.IdPaciente,
                IdUsuario = p.IdUsuario,
                Nombre = p.Nombre,
                Edad = p.Edad,
                Peso = p.Peso,
                Estatura = p.Estatura,
                Genero = p.Genero,
                Direccion = p.Direccion,
                NumeroTelefono = p.Telefono  // Aquí corregido
            })
            .ToListAsync();

        return Ok(pacientesDto);
    }

    // GET: api/Paciente/5
    [HttpGet("{id}")]
    public async Task<ActionResult<PacienteDTO>> GetPaciente(int id)
    {
        var pacienteDto = await _context.Pacientes
            .Where(p => p.IdPaciente == id)
            .Select(p => new PacienteDTO
            {
                IdPaciente = p.IdPaciente,
                IdUsuario = p.IdUsuario,
                Nombre = p.Nombre,
                Edad = p.Edad,
                Peso = p.Peso,
                Estatura = p.Estatura,
                Genero = p.Genero,
                Direccion = p.Direccion,
                NumeroTelefono = p.Telefono // corregido
            })
            .FirstOrDefaultAsync();

        if (pacienteDto == null)
            return NotFound();

        return Ok(pacienteDto);
    }

    // GET: api/Paciente/PorUsuario/{idUsuario}
    [HttpGet("PorUsuario/{idUsuario}")]
    public async Task<ActionResult<int>> GetIdPacientePorUsuario(int idUsuario)
    {
        var paciente = await _context.Pacientes
            .Where(p => p.IdUsuario == idUsuario)
            .Select(p => p.IdPaciente)
            .FirstOrDefaultAsync();

        if (paciente == 0) // no encontrado
            return NotFound();

        return Ok(paciente);
    }


    // POST: api/Paciente
    [HttpPost]
    public async Task<ActionResult<PacienteDTO>> CrearPaciente([FromBody] PacienteDTO dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var usuarioExiste = await _context.Usuarios.AnyAsync(u => u.IdUsuario == dto.IdUsuario);
        if (!usuarioExiste)
            return BadRequest("El usuario especificado no existe.");

        var paciente = new Paciente
        {
            IdUsuario = dto.IdUsuario,
            Nombre = dto.Nombre,
            Edad = dto.Edad,
            Peso = dto.Peso,
            Estatura = dto.Estatura,
            Genero = dto.Genero,
            Direccion = dto.Direccion,
            Telefono = dto.NumeroTelefono // corregido
        };

        _context.Pacientes.Add(paciente);
        await _context.SaveChangesAsync();

        dto.IdPaciente = paciente.IdPaciente; // si quieres agregar este campo al DTO para devolverlo

        return CreatedAtAction(nameof(GetPaciente), new { id = paciente.IdPaciente }, dto);
    }

    // PUT: api/Paciente/5
    [HttpPut("{id}")]
    public async Task<IActionResult> ActualizarPaciente(int id, [FromBody] PacienteDTO dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var paciente = await _context.Pacientes.FindAsync(id);
        if (paciente == null)
            return NotFound();

        var usuarioExiste = await _context.Usuarios.AnyAsync(u => u.IdUsuario == dto.IdUsuario);
        if (!usuarioExiste)
            return BadRequest("El usuario especificado no existe.");

        // Actualizar propiedades
        paciente.IdUsuario = dto.IdUsuario;
        paciente.Nombre = dto.Nombre;
        paciente.Edad = dto.Edad;
        paciente.Peso = dto.Peso;
        paciente.Estatura = dto.Estatura;
        paciente.Genero = dto.Genero;
        paciente.Direccion = dto.Direccion;
        paciente.Telefono = dto.NumeroTelefono;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            // Opcional: si quieres manejar concurrencia y notificar si no existe después de buscar
            if (!_context.Pacientes.Any(e => e.IdPaciente == id))
                return NotFound();
            else
                throw;
        }

        return NoContent();
    }

    // DELETE: api/Paciente/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> EliminarPaciente(int id)
    {
        var paciente = await _context.Pacientes.FindAsync(id);
        if (paciente == null)
            return NotFound();

        _context.Pacientes.Remove(paciente);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
