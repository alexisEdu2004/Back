﻿using Citas_Medicas.Context;
using Citas_Medicas.DTOs;
using Citas_Medicas.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Citas_Medicas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DetalleRecetaController : ControllerBase
    {
        private readonly DwpContext _context;

        public DetalleRecetaController(DwpContext context)
        {
            _context = context;
        }

        [HttpGet("PorReceta/{idReceta}")]
        public async Task<ActionResult<IEnumerable<DetalleRecetaDTO>>> GetDetallesPorReceta(int idReceta)
        {
            var detalles = await _context.DetalleRecetas
                .Where(d => d.IdReceta == idReceta)
                .Select(d => new DetalleRecetaDTO
                {
                    IdDetalleReceta = d.IdDetalleReceta,
                    IdReceta = d.IdReceta,
                    IdMedicamento = d.IdMedicamento,
                    Descripcion = d.Descripcion,
                    Dosis = d.Dosis,
                    Frecuencia = d.Frecuencia,
                    Duracion = d.Duracion
                }).ToListAsync();

            return Ok(detalles);
        }

        [HttpPost]
        public async Task<IActionResult> AgregarDetalle([FromBody] DetalleRecetaDTO detalleDto)
        {
            var recetaExiste = await _context.Recetas.AnyAsync(r => r.IdReceta == detalleDto.IdReceta);
            var medicamentoExiste = await _context.Medicamentos.AnyAsync(m => m.IdMedicamento == detalleDto.IdMedicamento);

            if (!recetaExiste || !medicamentoExiste)
                return BadRequest("Receta o medicamento no existente.");

            var yaExiste = await _context.DetalleRecetas.AnyAsync(d =>
                d.IdReceta == detalleDto.IdReceta && d.IdMedicamento == detalleDto.IdMedicamento);

            if (yaExiste)
                return BadRequest("Este medicamento ya está en la receta.");

            var detalle = new DetalleReceta
            {
                IdReceta = detalleDto.IdReceta,
                IdMedicamento = detalleDto.IdMedicamento,
                Descripcion = detalleDto.Descripcion,
                Dosis = detalleDto.Dosis,
                Frecuencia = detalleDto.Frecuencia,
                Duracion = detalleDto.Duracion
            };

            _context.DetalleRecetas.Add(detalle);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Detalle de receta agregado correctamente." });
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarDetalle(int id)
        {
            var detalle = await _context.DetalleRecetas.FindAsync(id);
            if (detalle == null)
                return NotFound();

            _context.DetalleRecetas.Remove(detalle);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Detalle eliminado correctamente." });
        }
    }
}
