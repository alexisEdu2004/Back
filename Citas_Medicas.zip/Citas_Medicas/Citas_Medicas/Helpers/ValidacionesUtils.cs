﻿using System.Text.RegularExpressions;

namespace Citas_Medicas.Helpers //Expresiones regulares para las contraseñas
{
    public static class ValidacionesUtils
    {
        public static bool EsCorreoValido(string correo)
        {
            return Regex.IsMatch(correo, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");
        }

        public static bool EsContrasenaSegura(string contraseña)
        {
            return contraseña.Length >= 8 &&
                   contraseña.Any(char.IsUpper) &&
                   contraseña.Any(char.IsLower) &&
                   contraseña.Any(char.IsDigit) &&
                   contraseña.Any(ch => "!@#$%^&*()_+-=[]{}|;:',.<>?/".Contains(ch));
        }
    }
}
