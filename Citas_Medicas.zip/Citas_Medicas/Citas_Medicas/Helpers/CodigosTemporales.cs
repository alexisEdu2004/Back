﻿using System;
using System.Collections.Generic;

namespace Citas_Medicas.Helpers
{
    public static class CodigosTemporales
    {
        // Para recuperación de contraseña
        public static Dictionary<string, (string Codigo, DateTime Expiracion)> CodigosRecuperacion =
            new Dictionary<string, (string Codigo, DateTime Expiracion)>();

        // Para verificación en login (2FA)
        public static Dictionary<string, (string Codigo, DateTime Expiracion)> CodigosLogin =
            new Dictionary<string, (string Codigo, DateTime Expiracion)>();
    }
}
