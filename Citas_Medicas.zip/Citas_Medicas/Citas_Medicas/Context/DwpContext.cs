﻿using System;
using System.Collections.Generic;
using Citas_Medicas.Models;
using Microsoft.EntityFrameworkCore;

namespace Citas_Medicas.Context;

public partial class DwpContext : DbContext
{
    public DwpContext()
    {
    }

    public DwpContext(DbContextOptions<DwpContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Agenda> Agendas { get; set; }

    public virtual DbSet<Cita> Citas { get; set; }

    public virtual DbSet<DetalleReceta> DetalleRecetas { get; set; }

    public virtual DbSet<Doctor> Doctores { get; set; }

    public virtual DbSet<Medicamento> Medicamentos { get; set; }

    public virtual DbSet<Notificacion> Notificaciones { get; set; }

    public virtual DbSet<Paciente> Pacientes { get; set; }

    public virtual DbSet<Receta> Recetas { get; set; }

    public virtual DbSet<Rol> Roles { get; set; }

    public virtual DbSet<Usuario> Usuarios { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Agenda>(entity =>
        {
            entity.HasKey(e => e.IdAgenda).HasName("PK__agenda__F03B5C753ABB997A");

            entity.ToTable("agenda");

            entity.Property(e => e.IdAgenda).HasColumnName("IDAgenda");
            entity.Property(e => e.DiaSemana).HasMaxLength(20);
            entity.Property(e => e.IdDoctor).HasColumnName("IDDoctor");

            entity.HasOne(d => d.IdDoctorNavigation).WithMany(p => p.Agendas)
                .HasForeignKey(d => d.IdDoctor)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__agenda__IDDoctor__4316F928");
        });

        modelBuilder.Entity<Cita>(entity =>
        {
            entity.HasKey(e => e.IdCita).HasName("PK__cita__36D350AB508D94E3");

            entity.ToTable("cita");

            entity.Property(e => e.IdCita).HasColumnName("IDCita");
            entity.Property(e => e.EstadoCita)
                .HasMaxLength(20)
                .HasDefaultValue("pendiente");
            entity.Property(e => e.IdAgenda).HasColumnName("IDAgenda");
            entity.Property(e => e.IdDoctor).HasColumnName("IDDoctor");
            entity.Property(e => e.IdPaciente).HasColumnName("IDPaciente");
            entity.Property(e => e.TipoServicio).HasMaxLength(100);

            entity.HasOne(d => d.IdAgendaNavigation).WithMany(p => p.Citas)
                .HasForeignKey(d => d.IdAgenda)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__cita__IDAgenda__47DBAE45");

            entity.HasOne(d => d.IdDoctorNavigation).WithMany(p => p.Citas)
                .HasForeignKey(d => d.IdDoctor)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__cita__IDDoctor__48CFD27E");

            entity.HasOne(d => d.IdPacienteNavigation).WithMany(p => p.Citas)
                .HasForeignKey(d => d.IdPaciente)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__cita__IDPaciente__46E78A0C");
        });

        modelBuilder.Entity<DetalleReceta>(entity =>
        {
            entity.HasKey(e => e.IdDetalleReceta).HasName("PK__detalleR__70250D8CDD52C605");

            entity.ToTable("detalleReceta");

            entity.Property(e => e.IdDetalleReceta).HasColumnName("IDDetalleReceta");
            entity.Property(e => e.Descripcion).HasMaxLength(255);
            entity.Property(e => e.Dosis).HasMaxLength(100);
            entity.Property(e => e.Duracion).HasMaxLength(100);
            entity.Property(e => e.Frecuencia).HasMaxLength(100);
            entity.Property(e => e.IdMedicamento).HasColumnName("IDMedicamento");
            entity.Property(e => e.IdReceta).HasColumnName("IDReceta");

            entity.HasOne(d => d.IdMedicamentoNavigation).WithMany(p => p.DetalleRecetas)
                .HasForeignKey(d => d.IdMedicamento)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__detalleRe__IDMed__52593CB8");

            entity.HasOne(d => d.IdRecetaNavigation).WithMany(p => p.DetalleRecetas)
                .HasForeignKey(d => d.IdReceta)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__detalleRe__IDRec__5165187F");
        });

        modelBuilder.Entity<Doctor>(entity =>
        {
            entity.HasKey(e => e.IdDoctor).HasName("PK__doctor__A4F7F9EC8D2286C8");

            entity.ToTable("doctor");

            entity.Property(e => e.IdDoctor).HasColumnName("IDDoctor");
            entity.Property(e => e.Apellido).HasMaxLength(100);
            entity.Property(e => e.Especialidad).HasMaxLength(100);
            entity.Property(e => e.IdUsuario).HasColumnName("IDUsuario");
            entity.Property(e => e.Nombre).HasMaxLength(100);
            entity.Property(e => e.Telefono).HasMaxLength(15);

            entity.HasOne(d => d.IdUsuarioNavigation).WithMany(p => p.Doctores)
                .HasForeignKey(d => d.IdUsuario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__doctor__IDUsuari__403A8C7D");
        });

        modelBuilder.Entity<Medicamento>(entity =>
        {
            entity.HasKey(e => e.IdMedicamento).HasName("PK__medicame__9228C2E42010DF3A");

            entity.ToTable("medicamento");

            entity.Property(e => e.IdMedicamento).HasColumnName("IDMedicamento");
            entity.Property(e => e.Descripcion).HasMaxLength(255);
            entity.Property(e => e.Nombre).HasMaxLength(100);
        });

        modelBuilder.Entity<Notificacion>(entity =>
        {
            entity.HasKey(e => e.IdNotificacion).HasName("PK__notifica__868713677FE9BFD2");

            entity.ToTable("notificaciones");

            entity.Property(e => e.IdNotificacion).HasColumnName("IDNotificacion");
            entity.Property(e => e.Descripcion).HasMaxLength(255);
            entity.Property(e => e.FechaEnvio)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.IdUsuario).HasColumnName("IDUsuario");
            entity.Property(e => e.Titulo).HasMaxLength(100);

            entity.HasOne(d => d.IdUsuarioNavigation).WithMany(p => p.Notificaciones)
                .HasForeignKey(d => d.IdUsuario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__notificac__IDUsu__5629CD9C");
        });

        modelBuilder.Entity<Paciente>(entity =>
        {
            entity.HasKey(e => e.IdPaciente).HasName("PK__paciente__94DF170F8AB666A1");

            entity.ToTable("paciente");

            entity.Property(e => e.IdPaciente).HasColumnName("IDPaciente");
            entity.Property(e => e.Apellido).HasMaxLength(100);
            entity.Property(e => e.Direccion).HasMaxLength(255);
            entity.Property(e => e.Estatura).HasColumnType("decimal(5, 2)");
            entity.Property(e => e.Genero).HasMaxLength(10);
            entity.Property(e => e.IdUsuario).HasColumnName("IDUsuario");
            entity.Property(e => e.Nombre).HasMaxLength(100);
            entity.Property(e => e.Peso).HasColumnType("decimal(5, 2)");
            entity.Property(e => e.Telefono).HasMaxLength(15);

            entity.HasOne(d => d.IdUsuarioNavigation).WithMany(p => p.Pacientes)
                .HasForeignKey(d => d.IdUsuario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__paciente__IDUsua__3D5E1FD2");
        });

        modelBuilder.Entity<Receta>(entity =>
        {
            entity.HasKey(e => e.IdReceta).HasName("PK__receta__91B4C6BC593337EA");

            entity.ToTable("receta");

            entity.Property(e => e.IdReceta).HasColumnName("IDReceta");
            entity.Property(e => e.IdDoctor).HasColumnName("IDDoctor");
            entity.Property(e => e.IdPaciente).HasColumnName("IDPaciente");

            entity.HasOne(d => d.IdDoctorNavigation).WithMany(p => p.Recetas)
                .HasForeignKey(d => d.IdDoctor)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__receta__IDDoctor__4E88ABD4");

            entity.HasOne(d => d.IdPacienteNavigation).WithMany(p => p.Recetas)
                .HasForeignKey(d => d.IdPaciente)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__receta__IDPacien__4D94879B");
        });

        modelBuilder.Entity<Rol>(entity =>
        {
            entity.HasKey(e => e.IdRol).HasName("PK__rol__A681ACB60D8CF432");

            entity.ToTable("rol");

            entity.Property(e => e.IdRol).HasColumnName("IDRol");
            entity.Property(e => e.NombreRol).HasMaxLength(50);
        });

        modelBuilder.Entity<Usuario>(entity =>
        {
            entity.HasKey(e => e.IdUsuario).HasName("PK__usuario__52311169D785C11E");

            entity.ToTable("usuario");

            entity.HasIndex(e => e.Correo, "UQ__usuario__60695A1936601ACD").IsUnique();

            entity.Property(e => e.IdUsuario).HasColumnName("IDUsuario");
            entity.Property(e => e.Contraseña).HasMaxLength(255);
            entity.Property(e => e.Correo).HasMaxLength(100);
            entity.Property(e => e.IdRol).HasColumnName("IDRol");

            entity.HasOne(d => d.IdRolNavigation).WithMany(p => p.Usuarios)
                .HasForeignKey(d => d.IdRol)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__usuario__IDRol__3A81B327");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
