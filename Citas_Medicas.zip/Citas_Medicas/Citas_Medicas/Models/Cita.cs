﻿using System;
using System.Collections.Generic;

namespace Citas_Medicas.Models;

public partial class Cita
{
    public int IdCita { get; set; }

    public int IdPaciente { get; set; }

    public int IdAgenda { get; set; }

    public int IdDoctor { get; set; }

    public string? TipoServicio { get; set; }

    public DateOnly FechaCita { get; set; }

    public TimeOnly HoraCita { get; set; }

    public string? EstadoCita { get; set; }

    public virtual Agenda IdAgendaNavigation { get; set; } = null!;

    public virtual Doctor IdDoctorNavigation { get; set; } = null!;

    public virtual Paciente IdPacienteNavigation { get; set; } = null!;
}
