﻿using System;
using System.Collections.Generic;

namespace Citas_Medicas.Models;

public partial class DetalleReceta
{
    public int IdDetalleReceta { get; set; }

    public int IdReceta { get; set; }

    public int IdMedicamento { get; set; }

    public string? Descripcion { get; set; }

    public string? Dosis { get; set; }

    public string? Frecuencia { get; set; }

    public string? Duracion { get; set; }

    public virtual Medicamento IdMedicamentoNavigation { get; set; } = null!;

    public virtual Receta IdRecetaNavigation { get; set; } = null!;
}
