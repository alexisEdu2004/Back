﻿using System;
using System.Collections.Generic;

namespace Citas_Medicas.Models;

public partial class Medicamento
{
    public int IdMedicamento { get; set; }

    public string Nombre { get; set; } = null!;

    public string? Descripcion { get; set; }

    public virtual ICollection<DetalleReceta> DetalleRecetas { get; set; } = new List<DetalleReceta>();
}
