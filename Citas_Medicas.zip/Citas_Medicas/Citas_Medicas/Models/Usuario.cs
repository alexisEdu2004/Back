﻿using System;
using System.Collections.Generic;

namespace Citas_Medicas.Models;

public partial class Usuario
{
    public int IdUsuario { get; set; }

    public string Correo { get; set; } = null!;

    public string Contraseña { get; set; } = null!;

    public int IdRol { get; set; }

    public virtual ICollection<Doctor> Doctores { get; set; } = new List<Doctor>();

    public virtual Rol IdRolNavigation { get; set; } = null!;

    public virtual ICollection<Notificacion> Notificaciones { get; set; } = new List<Notificacion>();

    public virtual ICollection<Paciente> Pacientes { get; set; } = new List<Paciente>();
}
