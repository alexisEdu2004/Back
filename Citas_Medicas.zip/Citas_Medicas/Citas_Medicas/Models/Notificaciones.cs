﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Citas_Medicas.Models;

[Table("Notificaciones")] // Aqui la cajeteamos con el nombre de la base de datos, voy a poner esto para no modificar todo 👍
public class Notificacion
{
    public int IdNotificacion { get; set; }

    public int IdUsuario { get; set; }

    public DateTime? FechaEnvio { get; set; }

    public string? Titulo { get; set; }

    public string? Descripcion { get; set; }

    public virtual Usuario IdUsuarioNavigation { get; set; } = null!;
}
