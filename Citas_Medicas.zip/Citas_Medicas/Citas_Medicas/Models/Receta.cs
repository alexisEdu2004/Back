﻿using System;
using System.Collections.Generic;

namespace Citas_Medicas.Models;

public partial class Receta
{
    public int IdReceta { get; set; }

    public int IdPaciente { get; set; }

    public int IdDoctor { get; set; }

    public DateOnly FechaEmision { get; set; }

    public virtual ICollection<DetalleReceta> DetalleRecetas { get; set; } = new List<DetalleReceta>();

    public virtual Doctor IdDoctorNavigation { get; set; } = null!;

    public virtual Paciente IdPacienteNavigation { get; set; } = null!;
}
