﻿using System;
using System.Collections.Generic;

namespace Citas_Medicas.Models;

public partial class Doctor
{
    public int IdDoctor { get; set; }

    public int IdUsuario { get; set; }

    public string? Nombre { get; set; }

    public string? Apellido { get; set; }

    public int? Edad { get; set; }

    public string? Especialidad { get; set; }

    public string? Telefono { get; set; }

    public virtual ICollection<Agenda> Agendas { get; set; } = new List<Agenda>();

    public virtual ICollection<Cita> Citas { get; set; } = new List<Cita>();

    public virtual Usuario IdUsuarioNavigation { get; set; } = null!;

    public virtual ICollection<Receta> Recetas { get; set; } = new List<Receta>();
}
